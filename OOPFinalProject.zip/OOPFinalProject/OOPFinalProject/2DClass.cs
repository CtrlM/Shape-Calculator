﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPFinalProject
{
    public class _2DClass
    {
       

     public int CircleArea(int r)
        {
            return (int)(Math.PI) * (r * r);
        }

    public int CircleCircumference( int r)
        {
            return 2 * (int)(Math.PI) * r;
        }
        public int SquareArea(int l, int w)
        {
            return l* w;
        }
        public int SquareCircumference(int l, int w)
        {
            return 2*l+ 2*w;
        }
        public int RectArea(int l, int w)
        {
            return l * w;
        }
        public int RectCircumference(int l, int w)
        {
            return  (2*l) + (2*w);
        }
        public int ParArea(int l, int w)
        {
            return l * w;
        }
        public int ParCircumference(int l, int w)
        {
            return 2 *(1+w);
        }
        public int RhombusArea(int l, int w)
        {
            return  (l*w)/2;
        }
        public int RhombusCircumference(int l, int w)
        {
            return  (2*l) + (2*w);
        }



    }
}
