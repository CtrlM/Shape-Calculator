﻿namespace OOPFinalProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pbCube = new System.Windows.Forms.PictureBox();
            this.pbRhombus = new System.Windows.Forms.PictureBox();
            this.pbParrallelogram = new System.Windows.Forms.PictureBox();
            this.pbRectangle = new System.Windows.Forms.PictureBox();
            this.pbCircle = new System.Windows.Forms.PictureBox();
            this.pbSquare = new System.Windows.Forms.PictureBox();
            this.pbCylinder = new System.Windows.Forms.PictureBox();
            this.pbPyramid = new System.Windows.Forms.PictureBox();
            this.pbSphere = new System.Windows.Forms.PictureBox();
            this.pbCone = new System.Windows.Forms.PictureBox();
            this.pbCuboid = new System.Windows.Forms.PictureBox();
            this.gb3 = new System.Windows.Forms.GroupBox();
            this.nudRadius = new System.Windows.Forms.NumericUpDown();
            this.nudHeight = new System.Windows.Forms.NumericUpDown();
            this.nudWidth = new System.Windows.Forms.NumericUpDown();
            this.nudLength = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cboOptions = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.gb2 = new System.Windows.Forms.GroupBox();
            this.nudR = new System.Windows.Forms.NumericUpDown();
            this.nudh = new System.Windows.Forms.NumericUpDown();
            this.nudl = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cbo2 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.cboCount = new System.Windows.Forms.ComboBox();
            this.btnCorrect = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbCube)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRhombus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbParrallelogram)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRectangle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCircle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSquare)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCylinder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPyramid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSphere)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCone)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCuboid)).BeginInit();
            this.gb3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudRadius)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLength)).BeginInit();
            this.gb2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudl)).BeginInit();
            this.SuspendLayout();
            // 
            // pbCube
            // 
            this.pbCube.Image = ((System.Drawing.Image)(resources.GetObject("pbCube.Image")));
            this.pbCube.Location = new System.Drawing.Point(12, 12);
            this.pbCube.Name = "pbCube";
            this.pbCube.Size = new System.Drawing.Size(100, 50);
            this.pbCube.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCube.TabIndex = 0;
            this.pbCube.TabStop = false;
            this.pbCube.Click += new System.EventHandler(this.pbCube_Click);
            // 
            // pbRhombus
            // 
            this.pbRhombus.AccessibleDescription = "df";
            this.pbRhombus.Image = ((System.Drawing.Image)(resources.GetObject("pbRhombus.Image")));
            this.pbRhombus.Location = new System.Drawing.Point(118, 236);
            this.pbRhombus.Name = "pbRhombus";
            this.pbRhombus.Size = new System.Drawing.Size(100, 50);
            this.pbRhombus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRhombus.TabIndex = 1;
            this.pbRhombus.TabStop = false;
            this.pbRhombus.Click += new System.EventHandler(this.pbRhombus_Click);
            // 
            // pbParrallelogram
            // 
            this.pbParrallelogram.Image = ((System.Drawing.Image)(resources.GetObject("pbParrallelogram.Image")));
            this.pbParrallelogram.Location = new System.Drawing.Point(118, 180);
            this.pbParrallelogram.Name = "pbParrallelogram";
            this.pbParrallelogram.Size = new System.Drawing.Size(100, 50);
            this.pbParrallelogram.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbParrallelogram.TabIndex = 2;
            this.pbParrallelogram.TabStop = false;
            this.pbParrallelogram.Click += new System.EventHandler(this.pbParrallelogram_Click);
            // 
            // pbRectangle
            // 
            this.pbRectangle.Image = ((System.Drawing.Image)(resources.GetObject("pbRectangle.Image")));
            this.pbRectangle.Location = new System.Drawing.Point(118, 124);
            this.pbRectangle.Name = "pbRectangle";
            this.pbRectangle.Size = new System.Drawing.Size(100, 50);
            this.pbRectangle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRectangle.TabIndex = 3;
            this.pbRectangle.TabStop = false;
            this.pbRectangle.Click += new System.EventHandler(this.pbRectangle_Click);
            // 
            // pbCircle
            // 
            this.pbCircle.Image = ((System.Drawing.Image)(resources.GetObject("pbCircle.Image")));
            this.pbCircle.Location = new System.Drawing.Point(118, 68);
            this.pbCircle.Name = "pbCircle";
            this.pbCircle.Size = new System.Drawing.Size(100, 50);
            this.pbCircle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCircle.TabIndex = 4;
            this.pbCircle.TabStop = false;
            this.pbCircle.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pbSquare
            // 
            this.pbSquare.Image = ((System.Drawing.Image)(resources.GetObject("pbSquare.Image")));
            this.pbSquare.Location = new System.Drawing.Point(118, 12);
            this.pbSquare.Name = "pbSquare";
            this.pbSquare.Size = new System.Drawing.Size(100, 50);
            this.pbSquare.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSquare.TabIndex = 5;
            this.pbSquare.TabStop = false;
            this.pbSquare.Click += new System.EventHandler(this.pbSquare_Click);
            this.pbSquare.DoubleClick += new System.EventHandler(this.pbSquare_DoubleClick);
            // 
            // pbCylinder
            // 
            this.pbCylinder.Image = ((System.Drawing.Image)(resources.GetObject("pbCylinder.Image")));
            this.pbCylinder.Location = new System.Drawing.Point(12, 292);
            this.pbCylinder.Name = "pbCylinder";
            this.pbCylinder.Size = new System.Drawing.Size(100, 50);
            this.pbCylinder.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCylinder.TabIndex = 6;
            this.pbCylinder.TabStop = false;
            this.pbCylinder.Click += new System.EventHandler(this.pbCylinder_Click);
            // 
            // pbPyramid
            // 
            this.pbPyramid.Image = ((System.Drawing.Image)(resources.GetObject("pbPyramid.Image")));
            this.pbPyramid.Location = new System.Drawing.Point(12, 236);
            this.pbPyramid.Name = "pbPyramid";
            this.pbPyramid.Size = new System.Drawing.Size(100, 50);
            this.pbPyramid.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbPyramid.TabIndex = 7;
            this.pbPyramid.TabStop = false;
            this.pbPyramid.Click += new System.EventHandler(this.pbPyramid_Click);
            // 
            // pbSphere
            // 
            this.pbSphere.Image = ((System.Drawing.Image)(resources.GetObject("pbSphere.Image")));
            this.pbSphere.Location = new System.Drawing.Point(12, 180);
            this.pbSphere.Name = "pbSphere";
            this.pbSphere.Size = new System.Drawing.Size(100, 50);
            this.pbSphere.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSphere.TabIndex = 8;
            this.pbSphere.TabStop = false;
            this.pbSphere.Click += new System.EventHandler(this.pbSphere_Click);
            // 
            // pbCone
            // 
            this.pbCone.Image = ((System.Drawing.Image)(resources.GetObject("pbCone.Image")));
            this.pbCone.Location = new System.Drawing.Point(12, 124);
            this.pbCone.Name = "pbCone";
            this.pbCone.Size = new System.Drawing.Size(100, 50);
            this.pbCone.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCone.TabIndex = 9;
            this.pbCone.TabStop = false;
            this.pbCone.Click += new System.EventHandler(this.pbCone_Click);
            // 
            // pbCuboid
            // 
            this.pbCuboid.Image = ((System.Drawing.Image)(resources.GetObject("pbCuboid.Image")));
            this.pbCuboid.Location = new System.Drawing.Point(12, 68);
            this.pbCuboid.Name = "pbCuboid";
            this.pbCuboid.Size = new System.Drawing.Size(100, 50);
            this.pbCuboid.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCuboid.TabIndex = 10;
            this.pbCuboid.TabStop = false;
            this.pbCuboid.Click += new System.EventHandler(this.pbCuboid_Click);
            // 
            // gb3
            // 
            this.gb3.Controls.Add(this.btnCorrect);
            this.gb3.Controls.Add(this.nudRadius);
            this.gb3.Controls.Add(this.nudHeight);
            this.gb3.Controls.Add(this.nudWidth);
            this.gb3.Controls.Add(this.nudLength);
            this.gb3.Controls.Add(this.label6);
            this.gb3.Controls.Add(this.label5);
            this.gb3.Controls.Add(this.label4);
            this.gb3.Controls.Add(this.label3);
            this.gb3.Controls.Add(this.cboOptions);
            this.gb3.Controls.Add(this.label2);
            this.gb3.Location = new System.Drawing.Point(251, 12);
            this.gb3.Name = "gb3";
            this.gb3.Size = new System.Drawing.Size(205, 196);
            this.gb3.TabIndex = 11;
            this.gb3.TabStop = false;
            this.gb3.Text = "3D shapes";
            // 
            // nudRadius
            // 
            this.nudRadius.Location = new System.Drawing.Point(80, 132);
            this.nudRadius.Name = "nudRadius";
            this.nudRadius.Size = new System.Drawing.Size(120, 22);
            this.nudRadius.TabIndex = 13;
            // 
            // nudHeight
            // 
            this.nudHeight.Location = new System.Drawing.Point(80, 104);
            this.nudHeight.Name = "nudHeight";
            this.nudHeight.Size = new System.Drawing.Size(120, 22);
            this.nudHeight.TabIndex = 12;
            // 
            // nudWidth
            // 
            this.nudWidth.Location = new System.Drawing.Point(80, 76);
            this.nudWidth.Name = "nudWidth";
            this.nudWidth.Size = new System.Drawing.Size(120, 22);
            this.nudWidth.TabIndex = 11;
            // 
            // nudLength
            // 
            this.nudLength.Location = new System.Drawing.Point(79, 48);
            this.nudLength.Name = "nudLength";
            this.nudLength.Size = new System.Drawing.Size(120, 22);
            this.nudLength.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 137);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 17);
            this.label6.TabIndex = 9;
            this.label6.Text = "Radius";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 109);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Height";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 17);
            this.label4.TabIndex = 7;
            this.label4.Text = "Width";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Length";
            // 
            // cboOptions
            // 
            this.cboOptions.FormattingEnabled = true;
            this.cboOptions.Items.AddRange(new object[] {
            "Area",
            "Volume"});
            this.cboOptions.Location = new System.Drawing.Point(79, 18);
            this.cboOptions.Name = "cboOptions";
            this.cboOptions.Size = new System.Drawing.Size(121, 24);
            this.cboOptions.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Options";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 370);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 17);
            this.label1.TabIndex = 12;
            this.label1.Text = "Results:";
            // 
            // txtResult
            // 
            this.txtResult.BackColor = System.Drawing.Color.DarkRed;
            this.txtResult.Location = new System.Drawing.Point(118, 365);
            this.txtResult.Name = "txtResult";
            this.txtResult.ReadOnly = true;
            this.txtResult.Size = new System.Drawing.Size(100, 22);
            this.txtResult.TabIndex = 13;
            // 
            // gb2
            // 
            this.gb2.Controls.Add(this.nudR);
            this.gb2.Controls.Add(this.btnCalculate);
            this.gb2.Controls.Add(this.nudh);
            this.gb2.Controls.Add(this.nudl);
            this.gb2.Controls.Add(this.label7);
            this.gb2.Controls.Add(this.label9);
            this.gb2.Controls.Add(this.label10);
            this.gb2.Controls.Add(this.cbo2);
            this.gb2.Controls.Add(this.label11);
            this.gb2.Location = new System.Drawing.Point(251, 214);
            this.gb2.Name = "gb2";
            this.gb2.Size = new System.Drawing.Size(205, 173);
            this.gb2.TabIndex = 14;
            this.gb2.TabStop = false;
            this.gb2.Text = "2D shapes";
            // 
            // nudR
            // 
            this.nudR.Location = new System.Drawing.Point(79, 106);
            this.nudR.Name = "nudR";
            this.nudR.Size = new System.Drawing.Size(120, 22);
            this.nudR.TabIndex = 13;
            // 
            // nudh
            // 
            this.nudh.Location = new System.Drawing.Point(80, 76);
            this.nudh.Name = "nudh";
            this.nudh.Size = new System.Drawing.Size(120, 22);
            this.nudh.TabIndex = 11;
            // 
            // nudl
            // 
            this.nudl.Location = new System.Drawing.Point(79, 48);
            this.nudl.Name = "nudl";
            this.nudl.Size = new System.Drawing.Size(120, 22);
            this.nudl.TabIndex = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(11, 111);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 17);
            this.label7.TabIndex = 9;
            this.label7.Text = "Radius";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 81);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 17);
            this.label9.TabIndex = 7;
            this.label9.Text = "Height";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 53);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 17);
            this.label10.TabIndex = 6;
            this.label10.Text = "Length";
            // 
            // cbo2
            // 
            this.cbo2.FormattingEnabled = true;
            this.cbo2.Items.AddRange(new object[] {
            "Area",
            "Circumference"});
            this.cbo2.Location = new System.Drawing.Point(79, 18);
            this.cbo2.Name = "cbo2";
            this.cbo2.Size = new System.Drawing.Size(121, 24);
            this.cbo2.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 21);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(57, 17);
            this.label11.TabIndex = 0;
            this.label11.Text = "Options";
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(6, 144);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(99, 23);
            this.btnCalculate.TabIndex = 15;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // cboCount
            // 
            this.cboCount.FormattingEnabled = true;
            this.cboCount.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11"});
            this.cboCount.Location = new System.Drawing.Point(162, 418);
            this.cboCount.Name = "cboCount";
            this.cboCount.Size = new System.Drawing.Size(121, 24);
            this.cboCount.TabIndex = 16;
            this.cboCount.Visible = false;
            // 
            // btnCorrect
            // 
            this.btnCorrect.Location = new System.Drawing.Point(6, 167);
            this.btnCorrect.Name = "btnCorrect";
            this.btnCorrect.Size = new System.Drawing.Size(99, 23);
            this.btnCorrect.TabIndex = 16;
            this.btnCorrect.Text = "Calculate";
            this.btnCorrect.UseVisualStyleBackColor = true;
            this.btnCorrect.Click += new System.EventHandler(this.btnCorrect_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gold;
            this.ClientSize = new System.Drawing.Size(506, 454);
            this.Controls.Add(this.cboCount);
            this.Controls.Add(this.gb2);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gb3);
            this.Controls.Add(this.pbCuboid);
            this.Controls.Add(this.pbCone);
            this.Controls.Add(this.pbSphere);
            this.Controls.Add(this.pbPyramid);
            this.Controls.Add(this.pbCylinder);
            this.Controls.Add(this.pbSquare);
            this.Controls.Add(this.pbCircle);
            this.Controls.Add(this.pbRectangle);
            this.Controls.Add(this.pbParrallelogram);
            this.Controls.Add(this.pbRhombus);
            this.Controls.Add(this.pbCube);
            this.Name = "Form1";
            this.Text = "Final OOP Project";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbCube)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRhombus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbParrallelogram)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRectangle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCircle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSquare)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCylinder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPyramid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSphere)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCone)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCuboid)).EndInit();
            this.gb3.ResumeLayout(false);
            this.gb3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudRadius)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLength)).EndInit();
            this.gb2.ResumeLayout(false);
            this.gb2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudl)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbCube;
        private System.Windows.Forms.PictureBox pbRhombus;
        private System.Windows.Forms.PictureBox pbParrallelogram;
        private System.Windows.Forms.PictureBox pbRectangle;
        private System.Windows.Forms.PictureBox pbCircle;
        private System.Windows.Forms.PictureBox pbSquare;
        private System.Windows.Forms.PictureBox pbCylinder;
        private System.Windows.Forms.PictureBox pbPyramid;
        private System.Windows.Forms.PictureBox pbSphere;
        private System.Windows.Forms.PictureBox pbCone;
        private System.Windows.Forms.PictureBox pbCuboid;
        private System.Windows.Forms.GroupBox gb3;
        private System.Windows.Forms.NumericUpDown nudRadius;
        private System.Windows.Forms.NumericUpDown nudHeight;
        private System.Windows.Forms.NumericUpDown nudWidth;
        private System.Windows.Forms.NumericUpDown nudLength;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboOptions;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.GroupBox gb2;
        private System.Windows.Forms.NumericUpDown nudR;
        private System.Windows.Forms.NumericUpDown nudh;
        private System.Windows.Forms.NumericUpDown nudl;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbo2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.ComboBox cboCount;
        private System.Windows.Forms.Button btnCorrect;
    }
}

