﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOPFinalProject
{
    public partial class Form1 : Form
    {
      
        
        public Form1()
        {
            InitializeComponent();
            
        }
        private void Erase2D()
        {
            nudh.Value=0;
            nudl.Value = 0;
            nudR.Value = 0;
            cbo2.SelectedIndex = -1;
            txtResult.Clear();

        }
        private void Erase3D()
        {
            nudHeight.Value = 0;
            nudLength.Value = 0;
            nudWidth.Value = 0;
            nudRadius.Value = 0;
            cboOptions.SelectedIndex = -1;
            txtResult.Clear();
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            gb2.Hide();
            gb3.Hide();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            gb2.Show();
            gb3.Hide();
            nudR.Show();
            cboCount.SelectedIndex = 1;
            Erase2D();

        }

        private void pbSquare_Click(object sender, EventArgs e)
        {
            gb2.Show();
            gb3.Hide();
            nudR.Hide();
            cboCount.SelectedIndex = 0;
            Erase2D();

        }

        private void pbRectangle_Click(object sender, EventArgs e)
        {
            gb2.Show();
            gb3.Hide();
            nudR.Hide();
            cboCount.SelectedIndex = 2;
            Erase2D();
        }

        private void pbParrallelogram_Click(object sender, EventArgs e)
        {
            gb2.Show();
            gb3.Hide();
            nudR.Hide();
            cboCount.SelectedIndex = 3;
            Erase2D();
        }

        private void pbRhombus_Click(object sender, EventArgs e)
        {
            gb2.Show();
            gb3.Hide();
            nudR.Hide();
            cboCount.SelectedIndex = 4;
            Erase2D();
        }

        private void pbCube_Click(object sender, EventArgs e)
        {
            gb3.Show();
            gb2.Hide();
            nudRadius.Hide();
            cboCount.SelectedIndex = 5;
            Erase3D();

        }


        private void pbCuboid_Click(object sender, EventArgs e)
        {
            gb3.Show();
            gb2.Hide();
            nudRadius.Hide();
            cboCount.SelectedIndex = 6;
            Erase3D();
        }

        private void pbCone_Click(object sender, EventArgs e)
        {
            gb3.Show();
            gb2.Hide();
            nudRadius.Hide();
            cboCount.SelectedIndex = 7;
            Erase3D();
        }

        private void pbSphere_Click(object sender, EventArgs e)
        {
            gb3.Show();
            gb2.Hide();
            nudRadius.Show();
            cboCount.SelectedIndex = 8;
            Erase3D();
        }

        private void pbPyramid_Click(object sender, EventArgs e)
        {
            gb3.Show();
            gb2.Hide();
            nudRadius.Hide();
            cboCount.SelectedIndex = 9;
            Erase3D();
        }

        private void pbCylinder_Click(object sender, EventArgs e)
        {
            gb3.Show();
            gb2.Hide();
            nudRadius.Hide();
            cboCount.SelectedIndex = 10;
            Erase3D();
        }

        private void pbSquare_DoubleClick(object sender, EventArgs e)
        {
           
        

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            _2DClass shape1 = new _2DClass();
            
            int l2, h2, r2;
           
            l2 = (int)nudl.Value;
            h2 = (int)nudh.Value;
            r2 = (int)nudR.Value;
            int result = 0;

            if (cbo2.SelectedIndex == 0)
            {
                if (cboCount.SelectedIndex == 0)
                {
                    result = shape1.SquareArea(l2, h2);
                }
                if (cboCount.SelectedIndex == 1)
                {
                    result = shape1.CircleArea(r2);
                }
                if (cboCount.SelectedIndex == 2)
                {
                    result = shape1.RectArea(l2, h2);
                }
                if (cboCount.SelectedIndex == 3)
                {
                    result = shape1.ParArea(l2, h2);
                }
                if (cboCount.SelectedIndex == 4)
                {
                    result = shape1.RhombusArea(l2, h2);
                }
            }
            else if (cbo2.SelectedIndex > 0)
            {


                if (cboCount.SelectedIndex == 0)
                {
                    result = shape1.SquareCircumference(l2,h2);
                }
                if (cboCount.SelectedIndex == 1)
                {
                    result = shape1.CircleCircumference(r2);
                }
                if (cboCount.SelectedIndex == 2)
                {
                    result = shape1.RectCircumference(l2,h2);
                }
                if (cboCount.SelectedIndex == 3)
                {
                    result = shape1.ParCircumference(l2,h2);
                }
                if (cboCount.SelectedIndex == 4)
                {
                    result = shape1.RhombusCircumference(l2,h2);
                }
            }
            txtResult.Text = result.ToString();
        }

        private void btnCorrect_Click(object sender, EventArgs e)
        {
            _3DClass shape3 = new _3DClass();
            int l3, w3, h3, r3;
            int result = 0;

            l3 = (int)nudLength.Value;
            w3 = (int)nudWidth.Value;
            h3 = (int)nudHeight.Value;
            r3 = (int)nudRadius.Value;
            if (cboOptions.SelectedIndex == 1)
            {
                if (cboCount.SelectedIndex == 5)
                {
                    result = shape3.CubeVolume(l3);
                }
                if (cboCount.SelectedIndex == 6)
                {
                    result = shape3.CuboidVolume(l3, w3, h3);
                }
                if (cboCount.SelectedIndex == 7)
                {
                    result = shape3.ConeVolume(l3, w3, h3, r3);
                }
                if (cboCount.SelectedIndex == 8)
                {
                    result = shape3.SphereVolume(r3);
                }
                if (cboCount.SelectedIndex == 9)
                {
                    result = shape3.PyramidVolume(l3, w3, h3);
                }
                if (cboCount.SelectedIndex == 10)
                {
                    result = shape3.CylinderVolume(h3, r3);
                }
            }
            else if (cboOptions.SelectedIndex == 0)
            {
                if(cboCount.SelectedIndex == 5)
                {
                 result= shape3.CubeArea(l3);
                }
                if (cboCount.SelectedIndex == 6)
                {
                    result = shape3.CuboidArea(l3, w3, h3);
                }
                if (cboCount.SelectedIndex == 7)
                {
                    result = shape3.ConeArea(l3, w3, h3,r3);
                }
                if (cboCount.SelectedIndex == 8)
                {
                    result = shape3.SphereArea(r3);
                }
                if (cboCount.SelectedIndex == 9)
                {
                    result = shape3.PyramidArea(l3, w3, h3);
                }
                if (cboCount.SelectedIndex == 10)
                {
                    result = shape3.CylinderArea(h3,r3);
                }


            }
           
            txtResult.Text =  result.ToString() ;
        }
    }
}
