﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPFinalProject
{
    public class _3DClass:_2DClass
    {
        public _3DClass(){
            }

        public int CubeArea(int l)
        {
          return  6 *(l*l);
        }

        public int CubeVolume(int l)
        {
            return l*l*l;
        }
        public int CuboidArea(int l, int w, int h)
        {
            return 2*((l*w)+(w*h)+(h*l));
        }

        public int CuboidVolume(int l,int w, int h)
        {
            return l * w * h;
        }
        public int ConeArea(int l, int w, int h, int r)
        {
            return( (int)(Math.PI)*r)*(r+((h*h)+(r*r))/2);
        }
        public int ConeVolume(int l, int w, int h, int r)
        {
            return ((int)(Math.PI)*(r*r))*(h/3);
        }
        public int SphereArea(int r)
        {
            return 4 * (int)(Math.PI)*(r*r) ;
        }
        public int SphereVolume(int r)
        {
            return (4/3) * (int)(Math.PI) * (r * r);
        }
        public int PyramidArea(int l, int w, int h)
        {
            return (l*w)+(l*((w/2)+(h)))+(w*((l/2)+(h)));
        }
        public int PyramidVolume(int l, int w, int h)
        {
            return (l*w*h)/3;
        }
        public int CylinderArea( int h, int r)
        {
            return (2*(int)(Math.PI)*r*h)+ (2 * (int)(Math.PI) * r * r);
        }
        public int CylinderVolume(int h, int r)
        {
            return (int)(Math.PI) * (r * r) * h;
        }



    }
}
